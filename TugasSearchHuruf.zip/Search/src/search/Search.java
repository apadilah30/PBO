/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package search;
import javax.swing.JOptionPane;

/**
 *
 * @author Agus Padilah
 */
public class Search {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String[] data = new String[5];
        int i;
        String huruf, key;
        boolean ketemu;
        
        for(i = 0;i < data.length; i++){
            huruf = JOptionPane.showInputDialog("Masukkan huruf/kata ke-"+(i+1));
            data[i] = huruf;
        }
        
        System.out.print("Huruf yang dimasukkan {");
        for(i = 0;i < data.length; i++){
            System.out.print(data[i]+", ");
        }
        System.out.println("}");
        
        key = JOptionPane.showInputDialog("Masukkan huruf/kata yang ingin dicari : ");
        
        System.out.println("Huruf/kata yang dicari : "+key);
        
        ketemu = false;
        
        for(i = 0;i < data.length; i++){
            if(data[i].equals(key)){
                ketemu = true;
                break;
            }
        }
        
        if(ketemu){
            System.out.println("Huruf/kata ditemukan di urutan ke-"+(i+1));
        } else {
            System.out.println("Huruf/kata tidak ditemukan");
        }
    }
    
}
